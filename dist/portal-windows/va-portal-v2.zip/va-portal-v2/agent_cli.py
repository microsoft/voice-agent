"""Publish, edit, inspect and talk to Foundry Voice Agents with the bundled Python, no portal needed.

Run it through agent.sh (Linux) or agent.cmd (Windows): they load portal.env (portal package) or
agent.env (command-line-only package) and use the bundled Python. It signs in exactly like the portal
(the VM's managed identity, or `az login` when AZURE_CREDENTIAL_MODE=cli) and talks only to the
project endpoint in AZURE_VOICE_AGENTS_ENDPOINT.

  agent check                                  read-only: DNS, identity, Foundry role, voice endpoint
  agent list                                   agents in the project, latest version and model
  agent show NAME [--version V] [--json]       summary, or the full definition with --json
  agent versions NAME                          every version, newest first
  agent pull NAME [--version V] [-o FILE]      save an agent as an editable agent.json
  agent publish FILE [--name NAME] [--model M] [--mcp-url URL] [--dry-run]
                                               publish FILE as a new version, then read it back
  agent edit NAME [--yes]                      pull, open in an editor, publish if changed
  agent rollback NAME VERSION [--yes]          publish an old version again as the newest one
  agent say NAME "turn" ["turn" ...] [--save F] text conversation: replies, handoffs, tool calls
  agent delete NAME [--version V] [--yes]      delete one version, or the whole agent

FILE is an agent.json ({name, description, definition}), a bare definition, or a `pull` result.
Every publish creates a new immutable version; earlier versions stay until you delete them.
"""

from __future__ import annotations

import argparse
import asyncio
import copy
import hashlib
import json
import logging
import os
import shutil
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote, urlparse

import truststore

# Verify HTTPS with the operating system's certificate store, not only the bundled certifi list: a network that
# inspects HTTPS re-signs it with an organization root CA that Windows trusts and certifi does not. Same call as
# the portal; it must run before requests and websockets build their SSL contexts.
truststore.inject_into_ssl()

import requests  # noqa: E402

API_VERSION = "v1"
TOKEN_SCOPE = "https://ai.azure.com/.default"  # same scope as portal/common.py
FEATURES = {"Foundry-Features": "VoiceAgents=V1Preview"}
ENTRA_HOST = "login.microsoftonline.com"
# Python, OpenSSL and truststore (Windows) wordings of a certificate the machine does not trust.
CERT_MARKERS = ("CERTIFICATE_VERIFY_FAILED", "SSLCertVerificationError", "certificate verify failed",
                "not trusted by the trust provider")
TEXT_DELTA = {"response.audio_transcript.delta", "response.output_audio_transcript.delta",
              "response.output_text.delta"}
TOOL_ITEMS = {"mcp_call", "function_call", "system_tool"}  # end_conversation is a system_tool
# Set by agent.sh / agent.cmd so messages name the file and command the customer actually has.
ENV_FILE = Path(os.getenv("AGENT_ENV_FILE") or "portal.env").name
CMD = os.getenv("AGENT_CMD") or "agent"


def die(message: str) -> None:
    sys.exit(f"ERROR: {message}")


def sign_in_mode() -> str:
    """The identity portal/common.py signs in with, named the way the env file configures it."""
    if os.getenv("AZURE_CREDENTIAL_MODE", "default").strip().lower() == "cli":
        return "cli"
    return "service principal" if os.getenv("AZURE_CLIENT_SECRET", "").strip() else "managed identity"


def cert_hint(error_text: str, host: str) -> str:
    """The fix in plain words when HTTPS to host failed certificate verification, else ''."""
    if not any(marker in error_text for marker in CERT_MARKERS):
        return ""
    return (f"HTTPS to {host} is signed by a certificate this machine does not trust. Usually the network "
            "inspects HTTPS and re-signs it with your organization's root CA. Install that CA in the machine's "
            "trusted root store (Windows: 'Trusted Root Certification Authorities'), or set REQUESTS_CA_BUNDLE "
            f"and SSL_CERT_FILE in {ENV_FILE} to the CA file, or exclude {host} from HTTPS inspection.")


def error_message(reply: requests.Response) -> str:
    """Foundry's own one-line error message, or the start of the body when there is none."""
    try:
        body = reply.json()
    except ValueError:
        body = None
    if isinstance(body, dict) and isinstance(body.get("error"), dict) and body["error"].get("message"):
        return str(body["error"]["message"])
    return reply.text[:500].strip() or reply.reason


class Foundry:
    """Calls to one Foundry project with the portal's identity choice."""

    def __init__(self, endpoint: str) -> None:
        endpoint = endpoint.strip().rstrip("/")
        parsed = urlparse(endpoint)
        if (parsed.scheme != "https" or "/api/projects/" not in parsed.path
                or "ACCOUNT.services" in endpoint or endpoint.endswith("/projects/PROJECT")):
            die(f"set AZURE_VOICE_AGENTS_ENDPOINT in {ENV_FILE} to "
                "https://<account>.services.ai.azure.com/api/projects/<project>")
        self.endpoint, self.host = endpoint, parsed.hostname
        self._credential = None
        self._token = None
        self.http = requests.Session()

    def token(self) -> str:
        if self._token is None or self._token.expires_on - time.time() < 300:
            from azure.core.exceptions import ClientAuthenticationError
            from azure.identity import AzureCliCredential, DefaultAzureCredential

            if self._credential is None:
                logging.getLogger("azure.identity").setLevel(logging.CRITICAL)  # one ERROR line instead
                cli = os.getenv("AZURE_CREDENTIAL_MODE", "default").strip().lower() == "cli"
                self._credential = (AzureCliCredential() if cli else
                                    DefaultAzureCredential(exclude_interactive_browser_credential=True))
            try:
                self._token = self._credential.get_token(TOKEN_SCOPE)
            except ClientAuthenticationError as error:
                lines = [line.strip() for line in str(error).splitlines() if line.strip()] or [type(error).__name__]
                # DefaultAzureCredential's first line only says the chain failed; the configured credential's line
                # (managed identity, or the service principal from AZURE_CLIENT_SECRET) says why.
                prefix = {"managed identity": "ManagedIdentityCredential:",
                          "service principal": "EnvironmentCredential:"}.get(sign_in_mode(), "\0")
                reason = next((line for line in lines if line.startswith(prefix)), lines[0])
                die(f"could not get a token for Foundry. {reason}\nRun `{CMD} check` for details.")
        return self._token.token

    def headers(self) -> dict:
        return {"Authorization": f"Bearer {self.token()}", **FEATURES}

    def call(self, method: str, path: str, *, body: dict | None = None, params: dict | None = None,
             missing_ok: bool = False) -> dict | None:
        try:
            reply = self.http.request(method, self.endpoint + path, json=body, timeout=120,
                                      params={"api-version": API_VERSION, **(params or {})},
                                      headers=self.headers())
        except requests.exceptions.ConnectionError:
            die(f"cannot reach {self.host}. Inside a VNet it must resolve to the Foundry private "
                f"endpoint; run `{CMD} check`.")
        if reply.status_code == 404 and missing_ok:
            return None
        if reply.status_code >= 400:
            hint = {401: f"the token was rejected; run `{CMD} check`",
                    403: "this identity needs the 'Foundry User' role (or higher) on the project",
                    404: f"not found; `{CMD} list` shows the agents in this project"}.get(reply.status_code, "")
            die(f"{method} {path} returned HTTP {reply.status_code}: {error_message(reply)}"
                + (f"\nHint: {hint}" if hint else ""))
        return reply.json() if reply.content else {}

    def pages(self, path: str):
        after = None
        while True:
            page = self.call("GET", path, params={"limit": 100, **({"after": after} if after else {})})
            yield from page.get("data") or []
            if not page.get("has_more") or not page.get("data"):
                return
            after = page.get("last_id") or page["data"][-1].get("id")

    def version(self, name: str, version: str | None) -> dict:
        """One version of an agent ({name, version, description, definition, ...}); latest by default."""
        if version:
            return self.call("GET", f"/agents/{quote(name, safe='')}/versions/{quote(version, safe='')}")
        agent = self.call("GET", f"/agents/{quote(name, safe='')}")
        return (agent.get("versions") or {}).get("latest") or die(f"{name} has no versions")


# ---------- agent definitions ----------

def read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))  # utf-8-sig: Notepad may add a BOM
    except FileNotFoundError:
        die(f"{path} does not exist")
    except json.JSONDecodeError as error:
        raise ValueError(f"{path} is not valid JSON: line {error.lineno}, column {error.colno}: {error.msg}")


def split_document(document: dict, source: str) -> tuple[str, str, dict]:
    """Return (name, description, definition) from an agent.json, a pull result or a bare definition."""
    if isinstance((document.get("versions") or {}).get("latest"), dict):  # raw GET /agents/{name}
        document = document["versions"]["latest"]
    definition = document.get("definition") if isinstance(document.get("definition"), dict) else document
    if definition.get("kind") != "voice":
        raise ValueError(f"{source}: definition.kind must be 'voice'")
    if not definition.get("model"):
        raise ValueError(f"{source}: definition.model is empty")
    name = document.get("name") if definition is not document else ""
    return str(name or ""), str(document.get("description") or ""), copy.deepcopy(definition)


def nodes(definition: dict) -> list[dict]:
    return list((definition.get("subagent_config") or {}).get("subagents") or [])


def mcp_tools(definition: dict) -> list[dict]:
    tools = list(definition.get("tools") or [])
    for node in nodes(definition):
        tools.extend(node.get("tools") or [])
    return [tool for tool in tools if isinstance(tool, dict) and tool.get("type") == "mcp"]


def fill_mcp(definition: dict, mcp_url: str | None) -> None:
    for tool in mcp_tools(definition):
        if mcp_url:
            tool["server_url"] = mcp_url
        if not tool.get("project_connection_id"):
            tool.pop("project_connection_id", None)
    empty = sorted({str(tool.get("server_label")) for tool in mcp_tools(definition) if not tool.get("server_url")})
    if empty:
        raise ValueError(f"MCP server(s) {', '.join(empty)} have no server_url; set it in the file or pass --mcp-url")


def fingerprint(definition: dict) -> str:
    canonical = json.dumps(definition, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]


def prompts(definition: dict) -> list:
    return [definition.get("model"), definition.get("instructions")] + [
        (node.get("id"), node.get("instructions")) for node in nodes(definition)]


def describe(definition: dict) -> str:
    ids = [str(node.get("id")) for node in nodes(definition)]
    servers = sorted({f"{t.get('server_label')} -> {t.get('server_url')}" for t in mcp_tools(definition)})
    lines = [f"model:       {definition.get('model')}",
             f"nodes:       {', '.join(ids) if ids else '(flat, no handoff)'}",
             f"fingerprint: {fingerprint(definition)}"]
    lines += [f"mcp:         {server}" for server in servers]
    return "\n".join(lines)


def changes(old: dict, new: dict) -> list[str]:
    found = [f"{key} changed" for key in sorted(set(old) | set(new))
             if key != "subagent_config" and old.get(key) != new.get(key)]
    before = {str(node.get("id")): node for node in nodes(old)}
    after = {str(node.get("id")): node for node in nodes(new)}
    found += [f"node {key} added" for key in after if key not in before]
    found += [f"node {key} removed" for key in before if key not in after]
    found += [f"node {key} changed" for key in after if key in before and after[key] != before[key]]
    if not found and old != new:
        found.append("subagent_config changed")
    return found


def confirm(question: str, assume_yes: bool) -> bool:
    if assume_yes:
        return True
    try:
        return input(f"{question} [y/N] ").strip().lower() in {"y", "yes"}
    except EOFError:
        return False


def stamp(value) -> str:
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    return str(value or "")


def publish(foundry: Foundry, name: str, definition: dict, description: str) -> str:
    """Create a new version, read it back, fail loudly if the stored prompts differ, and print the result.

    Foundry does not create a version whose content equals the latest one: it returns that version.
    """
    before = foundry.call("GET", f"/agents/{quote(name, safe='')}", missing_ok=True) or {}
    previous = str(((before.get("versions") or {}).get("latest") or {}).get("version") or "")
    created = foundry.call("POST", f"/agents/{quote(name, safe='')}/versions",
                           body={"definition": definition, "description": description})
    version = str(created.get("version"))
    stored = foundry.version(name, version).get("definition") or {}
    if prompts(stored) != prompts(definition):
        die(f"read-back of {name}:{version} does not match what was sent")
    if version == previous:
        print(f"unchanged:   identical to the latest version {name}:{version}; no new version created")
    else:
        print(f"published:   {name}:{version} (read back and matched; stored fingerprint {fingerprint(stored)})")
    return version


# ---------- text conversation over the agent's voice endpoint ----------

async def read_turn(ws, record: dict, state: dict, timeout: float, greeting: bool = False) -> None:
    """Read events until the agent has finished answering one caller turn."""
    from websockets.exceptions import ConnectionClosed

    text: list[str] = []
    handoff_pending = heard = False
    while True:
        try:
            # An agent without a greeting stays silent: give up waiting for it after 10 seconds.
            wait = min(timeout, 10.0) if greeting and not heard else timeout
            event = json.loads(await asyncio.wait_for(ws.recv(), timeout=wait))
        except asyncio.TimeoutError:
            if not (greeting and not heard):
                record["outcome"] = "stalled"  # a caller would hear silence
            break
        except ConnectionClosed:
            record["outcome"] = "ended"
            break
        kind, heard = event.get("type", ""), True
        if kind == "error":
            error = event.get("error") or {}
            record["errors"].append(f"{error.get('code') or error.get('type')}: {error.get('message')}")
        elif kind in TEXT_DELTA:
            text.append(event.get("delta") or "")
        elif kind == "session.handoff.started":
            handoff_pending = True
        elif kind in {"session.handoff.completed", "session.handoff.aborted"}:
            handoff_pending = False
            if kind.endswith("completed"):
                state["node"] = event.get("to_node_id") or state["node"]
                record["handoffs"].append([event.get("from_node_id"), event.get("to_node_id")])
        elif kind == "response.done":
            response = event.get("response") or {}
            output = [item for item in response.get("output") or [] if isinstance(item, dict)]
            for item in output:
                if item.get("type") in TOOL_ITEMS and item.get("name") != "handoff":
                    record["tools"].append(str(item.get("name")))
                    if item.get("error"):
                        record["errors"].append(f"tool {item.get('name')}: {item.get('error')}")
            if response.get("status") not in {None, "completed"}:
                record["errors"].append(f"response status {response.get('status')}")
            if not handoff_pending and not any(item.get("type") in TOOL_ITEMS for item in output):
                break  # nothing more is coming for this turn
    record["agent"], record["node"] = "".join(text).strip(), state["node"]


def show_turn(record: dict) -> None:
    if record["user"] is not None:
        print(f"\ncaller> {record['user']}")
    for source, target in record["handoffs"]:
        print(f"  handoff> {source} -> {target}")
    for name in record["tools"]:
        print(f"  tool> {name}")
    for error in record["errors"]:
        print(f"  error> {error}")
    print(f"  agent ({record['node'] or 'start'})> {record['agent'] or '<no speech>'}")
    if record["outcome"] != "ok":
        print(f"  outcome> {record['outcome']}")


def voice_url(foundry: Foundry, name: str) -> str:
    parsed = urlparse(foundry.endpoint)
    return (f"wss://{parsed.netloc}{parsed.path}/agents/{quote(name, safe='')}/endpoint/protocols/voice"
            f"?api-version={API_VERSION}&agent_session_id=cli-{uuid.uuid4().hex}")


async def converse(foundry: Foundry, name: str, turns: list[str], timeout: float) -> dict:
    from websockets.asyncio.client import connect

    url = voice_url(foundry, name)
    state = {"node": None}
    session: dict = {"agent": name, "conversation_id": None, "turns": []}
    async with connect(url, additional_headers=foundry.headers(), max_size=None, ping_timeout=None,
                       open_timeout=timeout) as ws:
        while True:  # wait until the session is configured
            event = json.loads(await asyncio.wait_for(ws.recv(), timeout=timeout))
            if event.get("type") == "session.created":
                session["conversation_id"] = event.get("conversation_id")
            elif event.get("type") == "error":
                die(f"session error: {event.get('error')}")
            elif event.get("type") == "session.updated":
                break
        for user in [None, *turns]:
            if session["turns"] and session["turns"][-1]["outcome"] != "ok":
                break  # the call ended or stalled; later turns cannot be judged
            record = {"user": user, "agent": "", "node": None, "tools": [], "handoffs": [],
                      "errors": [], "outcome": "ok"}
            if user is not None:
                await ws.send(json.dumps({"type": "conversation.item.create", "item": {
                    "type": "message", "role": "user", "content": [{"type": "input_text", "text": user}]}}))
                await ws.send(json.dumps({"type": "response.create"}))
            await read_turn(ws, record, state, timeout, greeting=user is None)
            session["turns"].append(record)
            show_turn(record)
    return session


# ---------- commands ----------

def load_file(path: Path, mcp_url: str | None = None) -> tuple[str, str, dict]:
    document = read_json(path)
    name, description, definition = split_document(document, str(path))
    fill_mcp(definition, mcp_url)
    return name, description, definition


async def probe_voice(foundry: Foundry) -> str:
    """Open the voice WebSocket for an agent name that does not exist: proves the WSS path without a session."""
    from websockets.asyncio.client import connect
    from websockets.exceptions import InvalidStatus

    try:
        async with connect(voice_url(foundry, f"agent-check-{uuid.uuid4().hex[:8]}"),
                           additional_headers=foundry.headers(), open_timeout=30):
            return "open"
    except InvalidStatus as error:
        return str(error.response.status_code)


def cmd_check(foundry: Foundry, args) -> int:
    """Read-only: one PASS / WARN / FAIL line per check; exit 1 if any check FAILs."""
    import base64
    import ipaddress
    import socket

    results: list[str] = []

    def report(status: str, name: str, detail: str) -> None:
        results.append(status)
        print(f"{status:<4}  {name}: {detail}")

    report("PASS", "Project endpoint", foundry.endpoint)
    try:  # inside a VNet without internet the Foundry host must resolve to its private endpoint
        addresses = sorted({info[4][0] for info in socket.getaddrinfo(foundry.host, 443)})
        private = all(ipaddress.ip_address(a).is_private for a in addresses)
        report("PASS" if private else "WARN", "Foundry address", f"{foundry.host} -> {', '.join(addresses)}"
               + ("" if private else " (public address: without internet access this will not connect; "
                  "check the Foundry private endpoint and its private DNS zone)"))
    except OSError as error:
        report("FAIL", "Foundry address", f"cannot resolve {foundry.host}: {error}")
    mode = sign_in_mode()
    try:
        token = foundry.token()
    except SystemExit as error:
        token = ""
        fix = {
            "managed identity": "On a VM: assign a managed identity to the VM, give it 'Foundry User' on the project, "
                                f"and put its client ID in AZURE_CLIENT_ID in {ENV_FILE}.",
            "service principal": f"Check AZURE_TENANT_ID, AZURE_CLIENT_ID and AZURE_CLIENT_SECRET in {ENV_FILE}; "
                                 f"this machine must reach https://{ENTRA_HOST} on port 443.",
            "cli": "Run `az login` on this machine (AZURE_CREDENTIAL_MODE=cli).",
        }[mode]
        text = str(error.code).removeprefix("ERROR: ")
        hint = cert_hint(text, ENTRA_HOST) if mode != "managed identity" else ""
        report("FAIL", "Identity", f"{text.splitlines()[0]} {hint or fix}")
    if token:
        payload = token.split(".")[1]
        claims = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
        app_id = claims.get("appid") or claims.get("azp")
        user = claims.get("upn") or claims.get("unique_name")
        client_id = os.getenv("AZURE_CLIENT_ID", "").strip()
        if user and claims.get("idtyp") != "app":  # AZURE_CREDENTIAL_MODE=cli: a person's az login
            report("PASS", "Identity", f"signed-in account {user}")
        elif client_id and app_id != client_id:
            report("WARN", "Identity", f"token is for {app_id}, not AZURE_CLIENT_ID {client_id}")
        else:
            kind = "service principal" if mode == "service principal" else "managed identity"
            report("PASS", "Identity", f"{kind} {app_id}")
        role_hint = "grant this identity the 'Foundry User' role on the project (Access control (IAM))"
        try:
            reply = foundry.http.get(f"{foundry.endpoint}/agents", params={"api-version": API_VERSION, "limit": 1},
                                     headers=foundry.headers(), timeout=30)
            if reply.ok:
                report("PASS", "Foundry access", "listed agents: the identity has a role on the project")
            elif reply.status_code in (401, 403):
                report("FAIL", "Foundry access", f"HTTP {reply.status_code}: {role_hint}")
            else:
                report("FAIL", "Foundry access", f"HTTP {reply.status_code}: {reply.text[:200]}")
        except requests.RequestException as error:
            report("FAIL", "Foundry access", cert_hint(str(error), foundry.host)
                   or f"cannot connect: {type(error).__name__}: {str(error)[:300]}")
        try:
            status = asyncio.run(probe_voice(foundry))
            if status in ("open", "404"):  # 404 for the made-up agent name means Foundry answered over WSS
                report("PASS", "Voice endpoint", "WSS reachable" + ("" if status == "open" else
                       " (HTTP 404 for a made-up agent name, as expected)"))
            elif status in ("401", "403"):
                report("FAIL", "Voice endpoint", f"WSS handshake HTTP {status}: {role_hint}")
            else:
                report("WARN", "Voice endpoint", f"WSS handshake HTTP {status} (expected 404 for a made-up agent "
                       "name): a proxy may be answering instead of Foundry; voice sessions may not connect")
        except Exception as error:  # noqa: BLE001 - TLS, proxy, timeout or a non-WebSocket reply: one line
            report("FAIL", "Voice endpoint", cert_hint(str(error), foundry.host)
                   or f"cannot open WSS to {foundry.host}: {type(error).__name__}: {str(error)[:200] or 'timeout'}. "
                   "A proxy or firewall may block WebSocket (wss://) even when HTTPS works.")
    print()
    if "FAIL" in results:
        print(f"Not ready: fix the FAIL lines above, then run `{CMD} check` again.")
        return 1
    print(f"Ready: try `{CMD} list`.")
    return 0


def cmd_list(foundry: Foundry, args) -> int:
    rows = list(foundry.pages("/agents"))
    if not rows:
        print("No agents in this project.")
    for agent in rows:
        latest = (agent.get("versions") or {}).get("latest") or {}
        definition = latest.get("definition") or {}
        print(f"{agent.get('name', ''):40} v{str(latest.get('version', '?')):<5} "
              f"{definition.get('kind', ''):7} {definition.get('model', '')}")
    return 0


def cmd_show(foundry: Foundry, args) -> int:
    version = foundry.version(args.name, args.version)
    if args.json:
        print(json.dumps(version, indent=2, ensure_ascii=False))
        return 0
    print(f"agent:       {args.name}:{version.get('version')}")
    print(f"created:     {stamp(version.get('created_at'))}")
    if version.get("description"):
        print(f"description: {version['description']}")
    print(describe(version.get("definition") or {}))
    return 0


def cmd_versions(foundry: Foundry, args) -> int:
    for version in foundry.pages(f"/agents/{quote(args.name, safe='')}/versions"):
        definition = version.get("definition") or {}
        print(f"v{str(version.get('version')):<5} {stamp(version.get('created_at')):21} "
              f"{definition.get('model', ''):24} {fingerprint(definition)}")
    return 0


def cmd_pull(foundry: Foundry, args) -> int:
    version = foundry.version(args.name, args.version)
    output = args.output or Path(f"{args.name}.json")
    document = {"name": args.name, "description": version.get("description") or "",
                "definition": version.get("definition") or {}}
    output.write_text(json.dumps(document, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Saved {args.name}:{version.get('version')} to {output}")
    print(f"Edit it, then publish it:  {CMD} publish {output}")
    return 0


def cmd_publish(foundry: Foundry, args) -> int:
    try:
        file_name, description, definition = load_file(args.file, args.mcp_url)
    except ValueError as error:
        die(str(error))
    if args.model:
        definition["model"] = args.model
    name = args.name or file_name or die("pass --name or set name in the file")
    description = description if args.description is None else args.description
    print(f"agent:       {name}")
    print(describe(definition))
    if args.dry_run:
        print("dry run: nothing published")
        return 0
    publish(foundry, name, definition, description)
    print(f'Try it:      {CMD} say {name} "Hello"')
    return 0


def pick_editor() -> str:
    editor = os.getenv("VISUAL") or os.getenv("EDITOR")
    if not editor:
        editor = "notepad" if os.name == "nt" else next((e for e in ("nano", "vi") if shutil.which(e)), "")
    return editor or die(f"no editor found; set EDITOR, or use `{CMD} pull` and `{CMD} publish`")


def cmd_edit(foundry: Foundry, args) -> int:
    current = foundry.version(args.name, None)
    old = copy.deepcopy(current.get("definition") or {})
    try:
        fill_mcp(old, None)  # same normalization the edited copy gets, so it compares fairly
    except ValueError:
        pass
    folder = Path(os.getenv("VOICE_PORTAL_DATA_DIR") or Path.home() / ".voice-agent-portal") / "agent-edits"
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{args.name}.json"
    document = {"name": args.name, "description": current.get("description") or "",
                "definition": current.get("definition") or {}}
    text = json.dumps(document, indent=2, ensure_ascii=False) + "\n"
    (folder / f"{args.name}.v{current.get('version')}.json").write_text(text, encoding="utf-8")
    path.write_text(text, encoding="utf-8")
    editor = pick_editor()
    print(f"Editing {args.name}:{current.get('version')} in {path}. Save and close the editor to continue.")
    while True:
        subprocess.call(f'{editor} "{path}"', shell=True)
        try:
            _, description, new = load_file(path)
            break
        except ValueError as error:
            print(f"ERROR: {error}")
            if not confirm("Open the editor again to fix it?", False):
                die(f"nothing published; your edits are still in {path}")
    found = changes(old, new)
    if description != (current.get("description") or ""):
        found.append("description changed")
    if not found:
        print("No changes; nothing published.")
        return 0
    print("Changes: " + "; ".join(found))
    if not confirm(f"Publish these changes as a new version of {args.name}?", args.yes):
        print(f"Not published. Your edits are in {path}; publish later with: {CMD} publish {path}")
        return 0
    publish(foundry, args.name, new, description)
    print(f"previous:    {args.name}:{current.get('version')} is kept; undo with: "
          f"{CMD} rollback {args.name} {current.get('version')}")
    return 0


def cmd_rollback(foundry: Foundry, args) -> int:
    old = foundry.version(args.name, args.version)
    latest = foundry.version(args.name, None)
    if (fingerprint(old.get("definition") or {}) == fingerprint(latest.get("definition") or {})
            and (old.get("description") or "") == (latest.get("description") or "")):
        print(f"The latest version ({latest.get('version')}) already has the content of version {args.version}.")
        return 0
    if not confirm(f"Publish the content of {args.name}:{args.version} as a new latest version?", args.yes):
        print("Cancelled.")
        return 0
    publish(foundry, args.name, old.get("definition") or {}, old.get("description") or "")
    print(f"rolled back: the latest version now has the content of version {args.version}")
    return 0


def cmd_say(foundry: Foundry, args) -> int:
    from websockets.exceptions import InvalidStatus

    turns = list(args.turns)
    if not turns:
        print("Type one caller turn per line; an empty line starts the call.")
        while line := input("caller> ").strip():
            turns.append(line)
    try:
        session = asyncio.run(converse(foundry, args.name, turns, args.timeout))
    except InvalidStatus as error:
        code = error.response.status_code
        reason = {401: f"the token was rejected; run `{CMD} check`",
                  403: "this identity needs the 'Foundry User' role (or higher) on the project",
                  404: f"no agent named {args.name} in this project; `{CMD} list` shows the agents"}.get(code, "")
        die(f"the voice endpoint refused the connection: HTTP {code}" + (f" ({reason})" if reason else ""))
    except (OSError, asyncio.TimeoutError) as error:
        die(f"cannot open the voice endpoint on {foundry.host} ({error or 'timeout'}); run `{CMD} check`")
    print(f"\nconversation_id: {session['conversation_id']}")
    if args.save:
        args.save.write_text(json.dumps(session, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return 1 if any(t["errors"] or t["outcome"] == "stalled" for t in session["turns"]) else 0


def cmd_delete(foundry: Foundry, args) -> int:
    target = f"{args.name}:{args.version}" if args.version else f"{args.name} (all versions)"
    if not confirm(f"Delete {target}? This cannot be undone.", args.yes):
        print("Cancelled.")
        return 0
    path = f"/agents/{quote(args.name, safe='')}"
    if args.version:
        path += f"/versions/{quote(args.version, safe='')}"
    foundry.call("DELETE", path)
    print(f"deleted {target}")
    return 0


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")  # a Windows console code page must not crash output
    parser = argparse.ArgumentParser(prog=CMD, description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--project-endpoint", default=os.getenv("AZURE_VOICE_AGENTS_ENDPOINT", ""),
                        help=f"default: AZURE_VOICE_AGENTS_ENDPOINT from {ENV_FILE}")
    sub = parser.add_subparsers(dest="command", required=True, metavar="COMMAND")
    sub.add_parser("check", help="read-only checks: DNS, identity, Foundry role, voice endpoint")
    sub.add_parser("list", help="agents in the project")
    show = sub.add_parser("show", help="one agent version")
    show.add_argument("name")
    show.add_argument("--version")
    show.add_argument("--json", action="store_true", help="print the full version as JSON")
    sub.add_parser("versions", help="every version of an agent").add_argument("name")
    pull = sub.add_parser("pull", help="save an agent as an editable agent.json")
    pull.add_argument("name")
    pull.add_argument("--version")
    pull.add_argument("-o", "--output", type=Path, help="default: ./NAME.json")
    pub = sub.add_parser("publish", help="publish a file as a new version")
    pub.add_argument("file", type=Path)
    pub.add_argument("--name", help="default: the file's name field")
    pub.add_argument("--model", help="override definition.model")
    pub.add_argument("--mcp-url", help="use this server_url for every MCP tool")
    pub.add_argument("--description")
    pub.add_argument("--dry-run", action="store_true", help="validate and print only")
    edit = sub.add_parser("edit", help="edit the latest version in an editor, publish if changed")
    edit.add_argument("name")
    edit.add_argument("--yes", action="store_true", help="publish without asking")
    back = sub.add_parser("rollback", help="publish an old version again as the newest one")
    back.add_argument("name")
    back.add_argument("version")
    back.add_argument("--yes", action="store_true")
    say = sub.add_parser("say", help="text conversation with a published agent")
    say.add_argument("name")
    say.add_argument("turns", nargs="*", help="caller turns; none = type them in")
    say.add_argument("--timeout", type=float, default=45.0, help="seconds of silence that count as a stall")
    say.add_argument("--save", type=Path, help="write the conversation to this JSON file")
    delete = sub.add_parser("delete", help="delete a version or the whole agent")
    delete.add_argument("name")
    delete.add_argument("--version", help="delete only this version")
    delete.add_argument("--yes", action="store_true")
    args = parser.parse_args()
    handlers = {"check": cmd_check, "list": cmd_list, "show": cmd_show, "versions": cmd_versions, "pull": cmd_pull,
                "publish": cmd_publish, "edit": cmd_edit, "rollback": cmd_rollback, "say": cmd_say,
                "delete": cmd_delete}
    if args.command == "publish" and args.dry_run:
        return cmd_publish(None, args)  # validation only: no endpoint or sign-in needed
    return handlers[args.command](Foundry(args.project_endpoint), args)


if __name__ == "__main__":
    sys.exit(main())
