@echo off
rem Publish, edit, inspect and talk to Voice Agents with the bundled Python. Run: agent.cmd --help
setlocal
rem portal.env in the portal package, agent.env in the command-line-only package
set "ENV_FILE=%~dp0portal.env"
if not exist "%ENV_FILE%" set "ENV_FILE=%~dp0agent.env"
for /f "usebackq eol=# tokens=1,* delims==" %%A in ("%ENV_FILE%") do set "%%A=%%B"
set PYTHONNOUSERSITE=1
set PYTHONUTF8=1
set "AGENT_ENV_FILE=%ENV_FILE%"
set "AGENT_CMD=agent.cmd"
if not defined VOICE_PORTAL_DATA_DIR set "VOICE_PORTAL_DATA_DIR=%USERPROFILE%\.voice-agent-portal"
"%~dp0python\python.exe" "%~dp0agent_cli.py" %*
exit /b %ERRORLEVEL%
