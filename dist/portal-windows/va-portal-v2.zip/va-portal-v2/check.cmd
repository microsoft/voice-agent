@echo off
rem Check identity, Foundry access and the local port before starting. Changes nothing.
setlocal
for /f "usebackq eol=# tokens=1,* delims==" %%A in ("%~dp0portal.env") do set "%%A=%%B"
set PYTHONNOUSERSITE=1
"%~dp0python\python.exe" "%~dp0check_env.py"
exit /b %ERRORLEVEL%
