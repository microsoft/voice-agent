# Voice Agent portal: offline package

This package runs the Voice Agent portal on one machine inside your network, with no internet access. It contains its own Python 3.12 and every dependency, already installed at the exact versions listed in `requirements.lock`. You do not need pip, git, Docker or the Azure CLI.

## What you need

| Item | Details |
|---|---|
| A Linux x64 VM in your virtual network | No public IP and no internet access needed. glibc 2.28 or newer (Ubuntu 20.04+, RHEL 8+). |
| A managed identity on that VM | A user-assigned identity is recommended. Give it the **Foundry User** role on your Foundry project (project > Access control (IAM) > Add role assignment). |
| Private access to your Foundry project | The VM must resolve `<account>.services.ai.azure.com` to your Foundry private endpoint. |

## Install and start

```bash
tar -xzf voice-agent-portal-<version>-linux-x64.tar.gz
cd voice-agent-portal-<version>-linux-x64
vi portal.env     # set AZURE_VOICE_AGENTS_ENDPOINT and AZURE_CLIENT_ID
./check.sh        # every line should be PASS
./start.sh        # the portal listens on 127.0.0.1:9527
```

To keep it running after you log out and start it at boot: `./install-service.sh` (needs sudo).

On a Windows x64 VM: extract `va-portal-v2.zip`, edit `portal.env` in Notepad, then run `check.cmd` and `start.cmd` from a Command Prompt in that folder. Keep the `start.cmd` window open while you use the portal.

## Open the portal

The portal accepts connections from the same machine only. From your computer, forward a local port to the VM through Azure Bastion:

```bash
az network bastion tunnel --name <bastion> --resource-group <rg> \
  --target-resource-id <vm resource id> --resource-port 22 --port 2222
# in a second terminal
ssh -p 2222 -L 9527:127.0.0.1:9527 <user>@127.0.0.1
```

Then open `http://127.0.0.1:9527/editor/` in your browser. On a Windows VM, sign in with Bastion remote desktop and open the same address in the VM's browser.

## Publish and edit agents from the command line

`./agent.sh` (`agent.cmd` on Windows) manages agents without the portal and without a browser. It uses the same `portal.env`, the same identity and the same Foundry endpoint as the portal, so it works wherever `./check.sh` passes. The portal does not need to be running.

```bash
./agent.sh check                                   # read-only: DNS, identity, Foundry role, voice endpoint
./agent.sh list                                    # agents in the project
./agent.sh publish examples/hotel_reservation/agent.json --name my-agent --mcp-url https://<your MCP server>/mcp
./agent.sh say my-agent "Hi, I want to book a room."   # text conversation: replies, handoffs, tool calls
./agent.sh edit my-agent                           # opens the latest version in an editor; publishes it if you changed it
./agent.sh show my-agent                           # model, nodes, MCP servers; --json for everything
./agent.sh versions my-agent
./agent.sh rollback my-agent 1                     # make version 1's content (definition and description) the latest again
./agent.sh pull my-agent -o my-agent.json          # save it as a file you can edit and `publish`
./agent.sh delete my-agent --version 2             # or the whole agent without --version
```

- Every publish creates a new version and keeps the older ones. If the content equals the latest version, Foundry keeps that version and no new one is created.
- After publishing, the command reads the version back and stops with an error if Foundry stored something different.
- `edit` uses `$EDITOR` (`nano` or `vi` if unset; Notepad on Windows) and keeps the pulled copy in `~/.voice-agent-portal/agent-edits/`.
- `say` sends text, not audio: it checks prompts, handoffs and tool calls, not speech recognition or voices.
- `examples/` holds two sample agents. Their tools point at an MCP server label without an address: pass `--mcp-url` with an MCP server your Foundry project can reach.
- `./agent.sh --help` lists every command and option. The `GUIDE.md` delivered with this package has a reference for each command, with example output and common errors.

## Identity

The portal calls Foundry as the VM's managed identity. The VM gets its token from the Azure Instance Metadata Service (`169.254.169.254`) inside the VM, so no internet access is needed. Everyone who uses the portal on this VM acts as that identity: they can publish and delete agents in the project and start sessions that incur cost.

To use a service principal instead, set `AZURE_TENANT_ID`, `AZURE_CLIENT_ID` and `AZURE_CLIENT_SECRET` in `portal.env` and give the service principal the **Foundry User** role on the project. The machine then gets its token from Microsoft Entra ID, so it must reach `https://login.microsoftonline.com` on port 443.

## Networks that inspect HTTPS

Some firewalls and proxies decrypt HTTPS and re-sign it with the organization's own root certificate. The portal, `check` and `agent` verify HTTPS against the certificates the operating system trusts (on Windows: **Trusted Root Certification Authorities**), so they work wherever the organization's root certificate is installed, as it usually is on managed machines. If `check` reports that a certificate is not trusted, install that root certificate on the machine, or set `REQUESTS_CA_BUNDLE` and `SSL_CERT_FILE` in `portal.env` to the certificate file (Base-64/PEM); on Windows that file is added to the trusted list, it does not replace it. Voice sessions use a WebSocket (`wss://`) to the Foundry host; `check` tests it too, because some proxies pass HTTPS but block WebSocket.

## Without internet access

- The project picker is not available; the portal uses the endpoint in `portal.env`.
- The live voice list is not available; the portal uses its built-in voice list.
- Avatar and WebRTC features are not available.
- Agent tools (MCP servers) are called by Foundry, not by this machine. Use MCP servers that your Foundry project can reach.

## Check the package

`SHA256SUMS` next to the download lists the package hash. `VERSION` shows the portal commit and Python build. `THIRD_PARTY_LICENSES.txt` lists the bundled packages and their licenses.

## Remove

Stop the portal (or `sudo systemctl disable --now voice-agent-portal` and delete `/etc/systemd/system/voice-agent-portal.service`), then delete this folder and `~/.voice-agent-portal`.
