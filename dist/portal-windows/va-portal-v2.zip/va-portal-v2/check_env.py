"""Pre-start checks for the offline Voice Agent portal package.

Run through check.sh / check.cmd, which load portal.env and use the bundled Python.
Prints one PASS / WARN / FAIL line per check and exits 1 if any check FAILs.
Changes nothing.
"""

from __future__ import annotations

import asyncio
import base64
import ipaddress
import json
import os
import socket
import sys
import uuid
from urllib.parse import urlparse

import truststore

# Verify HTTPS with the operating system's certificate store, not only the bundled certifi list: a network that
# inspects HTTPS re-signs it with an organization root CA that Windows trusts and certifi does not. Same call as
# the portal and agent_cli.py; it must run before requests and websockets build their SSL contexts.
truststore.inject_into_ssl()

TOKEN_SCOPE = "https://ai.azure.com/.default"  # same scope as portal/common.py
API_VERSION = "v1"
FEATURES = {"Foundry-Features": "VoiceAgents=V1Preview"}  # same header as agent_cli.py
ENTRA_HOST = "login.microsoftonline.com"
# Python, OpenSSL and truststore (Windows) wordings of a certificate the machine does not trust.
CERT_MARKERS = ("CERTIFICATE_VERIFY_FAILED", "SSLCertVerificationError", "certificate verify failed",
                "not trusted by the trust provider")
SIGN_IN_FIX = {
    "managed identity": "On a VM: assign a managed identity to the VM, give it 'Foundry User' on the project, "
                        "and put its client ID in AZURE_CLIENT_ID.",
    "service principal": "Check AZURE_TENANT_ID, AZURE_CLIENT_ID and AZURE_CLIENT_SECRET in portal.env; "
                         f"this machine must reach https://{ENTRA_HOST} on port 443.",
    "cli": "Run `az login` on this machine (AZURE_CREDENTIAL_MODE=cli).",
}
results: list[str] = []


def report(status: str, name: str, detail: str) -> None:
    results.append(status)
    print(f"{status:<4}  {name}: {detail}")


def claims(token: str) -> dict:
    payload = token.split(".")[1]
    return json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))


def sign_in_mode() -> str:
    """The identity portal/common.py signs in with, named the way portal.env configures it."""
    if os.getenv("AZURE_CREDENTIAL_MODE", "default").strip().lower() == "cli":
        return "cli"
    return "service principal" if os.getenv("AZURE_CLIENT_SECRET", "").strip() else "managed identity"


def cert_hint(error_text: str, host: str) -> str:
    """The fix in plain words when HTTPS to host failed certificate verification, else ''."""
    if not any(marker in error_text for marker in CERT_MARKERS):
        return ""
    return (f"HTTPS to {host} is signed by a certificate this machine does not trust. Usually the network "
            "inspects HTTPS and re-signs it with your organization's root CA. Install that CA in the machine's "
            "trusted root store (Windows: 'Trusted Root Certification Authorities'), or set REQUESTS_CA_BUNDLE "
            f"and SSL_CERT_FILE in portal.env to the CA file, or exclude {host} from HTTPS inspection.")


async def probe_voice(endpoint: str, token: str) -> str:
    """Open the voice WebSocket for an agent name that does not exist: proves the WSS path without a session."""
    from websockets.asyncio.client import connect
    from websockets.exceptions import InvalidStatus

    url = (f"{endpoint.replace('https://', 'wss://', 1)}/agents/agent-check-{uuid.uuid4().hex[:8]}"
           f"/endpoint/protocols/voice?api-version={API_VERSION}&agent_session_id=check-{uuid.uuid4().hex}")
    try:
        async with connect(url, additional_headers={"Authorization": f"Bearer {token}", **FEATURES},
                           open_timeout=30):
            return "open"
    except InvalidStatus as error:
        return str(error.response.status_code)


def main() -> int:
    endpoint = os.getenv("AZURE_VOICE_AGENTS_ENDPOINT", "").strip().rstrip("/")
    client_id = os.getenv("AZURE_CLIENT_ID", "").strip()
    port = int(os.getenv("DEMO_PORT", "9527"))
    mode = sign_in_mode()

    url = urlparse(endpoint)
    placeholder = "ACCOUNT.services" in endpoint or endpoint.endswith("/projects/PROJECT") or "<" in endpoint
    if url.scheme != "https" or not url.hostname or "/api/projects/" not in url.path or placeholder:
        report("FAIL", "Project endpoint", "set AZURE_VOICE_AGENTS_ENDPOINT in portal.env to "
               "https://<account>.services.ai.azure.com/api/projects/<project>")
        return 1
    report("PASS", "Project endpoint", endpoint)

    # 1. DNS: inside a VNet without internet the Foundry host must resolve to its private endpoint.
    try:
        addresses = sorted({info[4][0] for info in socket.getaddrinfo(url.hostname, 443)})
        private = all(ipaddress.ip_address(a).is_private for a in addresses)
        report("PASS" if private else "WARN", "Foundry address",
               f"{url.hostname} -> {', '.join(addresses)}"
               + ("" if private else " (public address: without internet access this will not connect; "
                  "check the private endpoint and its private DNS zone)"))
    except OSError as error:
        report("FAIL", "Foundry address", f"cannot resolve {url.hostname}: {error}")

    # 2. Token: a VM managed identity comes from IMDS (169.254.169.254) with no internet; a service principal
    #    (AZURE_CLIENT_SECRET) and `az login` need Microsoft Entra ID at login.microsoftonline.com.
    token = ""
    import logging

    logging.getLogger("azure.identity").setLevel(logging.CRITICAL)  # keep only our one-line verdict
    try:
        from azure.identity import AzureCliCredential, DefaultAzureCredential

        # Same choice as portal/common.py: AZURE_CREDENTIAL_MODE=cli uses `az login`, otherwise the default chain
        # (AZURE_CLIENT_SECRET set: that service principal; on a VM otherwise: the managed identity through IMDS).
        credential = (AzureCliCredential() if mode == "cli"
                      else DefaultAzureCredential(exclude_interactive_browser_credential=True))
        token = credential.get_token(TOKEN_SCOPE).token
        c = claims(token)
        user = (c.get("upn") or c.get("unique_name")) if c.get("idtyp") != "app" else None
        who = user or c.get("appid") or c.get("azp") or c.get("oid")
        if user:  # AZURE_CREDENTIAL_MODE=cli: a person's az login (appid is then the Azure CLI's own app)
            report("PASS", "Identity", f"signed-in account {user}")
        elif client_id and who != client_id:
            report("WARN", "Identity", f"token is for {who}, not AZURE_CLIENT_ID {client_id}")
        else:
            kind = "service principal" if mode == "service principal" else "managed identity"
            report("PASS", "Identity", f"{kind} {who}")
    except Exception as error:  # noqa: BLE001 - report any credential failure in plain words
        lines = [line.strip() for line in str(error).splitlines() if line.strip()] or [type(error).__name__]
        # DefaultAzureCredential's first line only says the chain failed; the configured credential's line says why.
        prefix = {"managed identity": "ManagedIdentityCredential:", "service principal": "EnvironmentCredential:"}
        reason = next((line for line in lines if line.startswith(prefix.get(mode, "\0"))), lines[0])
        hint = cert_hint(str(error), ENTRA_HOST) if mode != "managed identity" else ""
        report("FAIL", "Identity", f"no token as {mode} ({reason[:300]}). {hint or SIGN_IN_FIX[mode]}")

    # 3. Foundry access with that token (proves the HTTPS path and the Foundry User role).
    role_hint = "grant this identity the 'Foundry User' role on the project (Access control (IAM))"
    if token:
        import requests

        try:
            response = requests.get(f"{endpoint}/agents", params={"api-version": API_VERSION},
                                    headers={"Authorization": f"Bearer {token}"}, timeout=30)
            if response.ok:
                count = len(response.json().get("data", []))
                report("PASS", "Foundry access", f"listed agents ({count} on the first page)")
            elif response.status_code in (401, 403):
                report("FAIL", "Foundry access", f"HTTP {response.status_code}: {role_hint}")
            else:
                report("FAIL", "Foundry access", f"HTTP {response.status_code}: {response.text[:200]}")
        except requests.RequestException as error:
            report("FAIL", "Foundry access", cert_hint(str(error), url.hostname)
                   or f"cannot connect: {type(error).__name__}: {str(error)[:300]}")

    # 4. Voice endpoint: the portal's voice sessions use a WebSocket (wss://) to the same host. Some proxies pass
    #    HTTPS but block WebSocket upgrades, so check it separately.
    if token:
        try:
            status = asyncio.run(probe_voice(endpoint, token))
            if status in ("open", "404"):  # 404 for the made-up agent name means Foundry answered over WSS
                report("PASS", "Voice endpoint", "WSS reachable" + ("" if status == "open" else
                       " (HTTP 404 for a made-up agent name, as expected)"))
            elif status in ("401", "403"):
                report("FAIL", "Voice endpoint", f"WSS handshake HTTP {status}: {role_hint}")
            else:
                report("WARN", "Voice endpoint", f"WSS handshake HTTP {status} (expected 404 for a made-up agent "
                       "name): a proxy may be answering instead of Foundry; voice sessions may not connect")
        except Exception as error:  # noqa: BLE001 - TLS, proxy, timeout: say it in one line
            report("FAIL", "Voice endpoint", cert_hint(str(error), url.hostname)
                   or f"cannot open WSS to {url.hostname}: {type(error).__name__}: {str(error)[:200]}. "
                   "A proxy or firewall may block WebSocket (wss://) even when HTTPS works.")

    # 5. Local port.
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("127.0.0.1", port))
            report("PASS", "Local port", f"127.0.0.1:{port} is free")
        except OSError:
            report("FAIL", "Local port", f"127.0.0.1:{port} is in use: stop the other process or set DEMO_PORT")

    print()
    if "FAIL" in results:
        print("Not ready: fix the FAIL lines above, then run the check again.")
        return 1
    print("Ready: run the start script.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
